/*
 ** Copyright (c) 2020 Oracle and/or its affiliates.
 */

export * from '@oracle-cx-commerce/react-widgets';
export const _OpenpixCheckoutCash = () => import('./openpix-checkout-cash');
export const _OpenpixCheckoutOrderConfirmation = () => import('./openpix-checkout-order-confirmation');
export const _OpenpixPaymentDetails = () => import('./openpix-payment-details');
