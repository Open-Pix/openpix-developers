import {getCurrentOrder, getCurrentProfile, getOrder, getPage} from '@oracle-cx-commerce/commerce-utils/selector';
import {
  isPaymentEnabledForApproval,
  isPaymentTypeEnabled,
  isPaymentDisabled,
  getPaymentEnabledForScheduledOrder,
  getPaymentGroupsByTypes,
} from '@oracle-cx-commerce/react-components/utils/payment';
import { PAYMENT_TYPE_CASH } from '@oracle-cx-commerce/commerce-utils/constants';

/**
 * Returns widget's required data
 * @param {Object} state the state object
 * @returns required data
 */
export const getComponentData = state => {
  const contextOrderId = getPage(state).contextId;
  const order = contextOrderId ? getOrder(state, {id: contextOrderId}) : getCurrentOrder(state);

  return {
    isPaymentDisabled: isPaymentDisabled(order),
    isDisplayCheckoutCash: isPaymentTypeEnabled(state, PAYMENT_TYPE_CASH),
    appliedCashPaymentGroups: getPaymentGroupsByTypes(order, [PAYMENT_TYPE_CASH]),
    isPaymentMethodEnabledForApproval: isPaymentEnabledForApproval(state, PAYMENT_TYPE_CASH),
    isApprovalEnabled: getCurrentProfile(state).derivedApprovalRequired,
    PaymentInfoForScheduledOrder: getPaymentEnabledForScheduledOrder(state, PAYMENT_TYPE_CASH)
  };
};
