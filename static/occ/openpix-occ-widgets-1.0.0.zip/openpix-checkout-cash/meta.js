import {mergeDefaultConfig} from '@oracle-cx-commerce/react-widgets/config';
import config from './config';
import * as en from './locales/en';
import * as pt_BR from './locales/pt_BR';

/**
 * Metadata for the widget.
 */
export default {
  name: '_OpenpixCheckoutCash',
  description: 'OpenPix Checkout Cash',
  author: 'OpenPix',
  config: mergeDefaultConfig(config),
  resources: {
    en,
    pt_BR,
  },
  availableToAllPages: false,
  pageTypes: ['checkout-payment', 'pending-payment'],
  requiresContext: ['payment_context']
};
