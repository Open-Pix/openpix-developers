import React, { useCallback, useContext, useEffect, useRef, useState } from 'react';
import Styled from '@oracle-cx-commerce/react-components/styled';
import {connect} from '@oracle-cx-commerce/react-components/provider';
import {validatePaymentsEnabled} from '@oracle-cx-commerce/react-components/utils/payment';

import css from './styles.css';
import {getComponentData} from './selectors';
import {PaymentsContext} from '@oracle-cx-commerce/react-ui/contexts';
import { PAYMENT_TYPE_CASH } from '@oracle-cx-commerce/commerce-utils/constants';
import RadioButton from '@oracle-cx-commerce/react-components/radio';
import CheckoutBillingAddress from '@oracle-cx-commerce/react-widgets/checkout/checkout-credit-card/components/checkout-billing-address';

const OpenpixCheckoutCash = props => {
  const {
    id,
    isPaymentDisabled,
    isDisplayCheckoutCash,
    isApprovalEnabled = false,
    isPaymentMethodEnabledForApproval,
    PaymentInfoForScheduledOrder,
    appliedCashPaymentGroups,
    labelPayWithPix,
    ...remainingProps
  } = props;
  const paymentContext = useContext(PaymentsContext) || {};
  const {
    payments = [],
    selectedPaymentType,
    addOrUpdatePaymentToContext,
    isApprovalRequired,
    setSelectedPaymentType,
    removePaymentFromContextByType,
    updateSelectedPaymentType
  } = paymentContext;
  const formRef = useRef(null);

  const [paymentDetails, setPaymentDetails] = useState({type: PAYMENT_TYPE_CASH});

  // console.log('OpenpixCheckoutCash: ', {
  //   props,
  //   paymentContext,
  //   paymentDetails,
  // });

  let appliedPaymentGroupBillingAddress;
  if (appliedCashPaymentGroups.length) {
    const {billingAddress} = appliedCashPaymentGroups[0];
    appliedPaymentGroupBillingAddress = billingAddress;
  }

  // useEffect will set selectedPaymentType (which to set payment radio button as checked) if payment already applied
  useEffect(() => {
    if (appliedCashPaymentGroups.length && !isPaymentDisabled) {
      setSelectedPaymentType(PAYMENT_TYPE_CASH);
    }
  }, [appliedCashPaymentGroups, isPaymentDisabled, setSelectedPaymentType]);

  /**
   * Update the payment details with user provided address
   * @param {object} The billing Address
   */
  const updateAddress = useCallback(
    address => {
      setPaymentDetails(paymentDetails => {
        return {...paymentDetails, ...address};
      });
    },
    [setPaymentDetails]
  );

  /**
   * This method gets invoked on selection of current payment's radio button.
   * It sets the current payment as the selected payment type
   */
  const onPayByOpenPixCashSelection = useCallback(() => {
    updateSelectedPaymentType(PAYMENT_TYPE_CASH);
  }, [updateSelectedPaymentType]);

  // this useEffect will add current payment in the payment context
  // on radio button selection and if payment get disable then it reset the selected payment type
  // and removes the applied in store payment
  useEffect(() => {
    if (selectedPaymentType !== PAYMENT_TYPE_CASH) {
      return
    }

    const existingCashPayment = payments.find(payment => payment.type === PAYMENT_TYPE_CASH);

    if (!isPaymentDisabled && paymentDetails.billingAddress && paymentDetails.billingAddress.country) {
      const paymentGroupId =
        appliedCashPaymentGroups.length !== 0 ? appliedCashPaymentGroups[0].paymentGroupId : null;

      const payment = paymentGroupId ? {...paymentDetails, paymentGroupId} : paymentDetails;

      if (
        !existingCashPayment ||
        existingCashPayment.billingAddress !== payment.billingAddress
      ) {
        addOrUpdatePaymentToContext(payment);
      }

      return;
    }

    if (
      isPaymentDisabled ||
      ((!paymentDetails.billingAddress || !paymentDetails.billingAddress.country) && existingCashPayment)
    ) {
      removePaymentFromContextByType(PAYMENT_TYPE_CASH);
      if (isPaymentDisabled) {
        setSelectedPaymentType('');
      }
    }
  }, [
    selectedPaymentType,
    isPaymentDisabled,
    paymentDetails,
    payments,
    addOrUpdatePaymentToContext,
    removePaymentFromContextByType,
    setSelectedPaymentType
  ]);

  if (!isDisplayCheckoutCash) {
    return null;
  }

  if (
    !validatePaymentsEnabled(
      isApprovalRequired,
      isApprovalEnabled,
      isPaymentMethodEnabledForApproval,
      PaymentInfoForScheduledOrder
    )
  ) {
    return null;
  }

  return (
    <Styled id="OpenpixCheckoutCash" css={css}>
      <div className="OpenpixCheckoutCash CheckoutPaymentsGroup">
        <div className="OpenpixCheckoutCash__RadioButtonContainer">
          <RadioButton
            id={`checkout-openpixPayment-${id}`}
            name="CheckoutPayments"
            disabled={isPaymentDisabled}
            checked={selectedPaymentType === PAYMENT_TYPE_CASH}
            labelText={labelPayWithPix}
            value={PAYMENT_TYPE_CASH}
            onChange={onPayByOpenPixCashSelection}
          />
        </div>
        <div
          className={
            selectedPaymentType === PAYMENT_TYPE_CASH
              ? 'OpenpixCheckoutCash__DetailsContainer'
              : 'OpenpixCheckoutCash__DetailsContainer--Hidden'
          }
        >
          <form ref={formRef}>
            <CheckoutBillingAddress
              {...remainingProps}
              id={id}
              onInput={updateAddress}
              appliedPaymentGroupBillingAddress={appliedPaymentGroupBillingAddress}
            />
          </form>
        </div>
      </div>
    </Styled>
  );
};

export default connect(getComponentData)(OpenpixCheckoutCash);
