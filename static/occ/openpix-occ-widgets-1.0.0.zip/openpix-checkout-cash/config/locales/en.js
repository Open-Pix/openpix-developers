export const includeExtraInfoLabel = 'Display extra info';
export const includeExtraInfoHelpText = 'If selected, the display will include some extra info.';
