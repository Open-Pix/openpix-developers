/**
 * Design Studio configuration properties for the WidgetName component.
 */
const config = {
  properties: [],
  locales: {}
};

export default config;
