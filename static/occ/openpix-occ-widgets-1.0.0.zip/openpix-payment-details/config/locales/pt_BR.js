export const includeExtraInfoLabel = '[pt_BR]Display extra info[pt_BR]';
export const includeExtraInfoHelpText = '[pt_BR]If selected, the display will include some extra info.[pt_BR]';
