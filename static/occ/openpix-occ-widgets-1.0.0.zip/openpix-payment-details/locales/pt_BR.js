export const actionProceedToPayment = 'Prosseguir para Pagamento';
export const headingPaymentMethod = 'Detalhes do Pagamento';
export const textGiftCard = 'Cartão-presente';
export const textBillingAddress = 'Endereço de Faturamento';
export const labelEdit = 'Editar';
export const textAdditionalPaymentInformationNeeded = 'São necessárias informações adicionais de pagamento para concluir seu pedido.';
export const textExpiryDate = 'Data de Vencimento: __MONTH__/__YEAR__';
export const textOrderPendingPayment = 'Pedido com Pagamento Pendente';
export const textPayInStore = 'Pagamento do pedido na loja';
export const textInvoice = 'Fatura';
export const textPONumber = 'Número da OC:';
export const textPayAfterApproval = 'Pagar Depois da Aprovação';
export const textPayOnline = 'Pagando pedido on-line';

export const labelPayWithPix = 'Pagar com Pix';
