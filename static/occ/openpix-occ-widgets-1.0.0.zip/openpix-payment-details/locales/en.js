export const actionProceedToPayment = 'Proceed To Payment';
export const headingPaymentMethod = 'Payment Details';
export const textGiftCard = 'Gift Card';
export const textBillingAddress = 'Billing Address';
export const labelEdit = 'Edit';
export const textAdditionalPaymentInformationNeeded = 'Additional payment information is needed to complete your order.';
export const textExpiryDate = 'Expiry Date: __MONTH__/__YEAR__';
export const textOrderPendingPayment = 'Order Pending Payment';
export const textPayInStore = 'Paying for order in store';
export const textInvoice = 'Invoice';
export const textPONumber = 'PO Number:';
export const textPayAfterApproval = 'Pay After Approval';
export const textPayOnline = 'Paying for order online';

// OpenPix
export const labelPayWithPix = 'Pay with Pix';
