/*
 ** Copyright (c) 2020 Oracle and/or its affiliates.
 */
import React from 'react';
import {CreditCardPaymentDetails} from '@oracle-cx-commerce/react-widgets/profile/payment-information/components/credit-card';
import {GiftCardPaymentDetails} from '@oracle-cx-commerce/react-widgets/profile/payment-information/components/gift-card';
import {InvoicePaymentDetails} from '@oracle-cx-commerce/react-widgets/profile/payment-information/components/invoice-payment';
import {GeneralPaymentDetails} from '@oracle-cx-commerce/react-widgets/profile/payment-information/components/general-payment-details';
import {
  PAYMENT_TYPE_GIFTCARD,
  PAYMENT_METHOD_TOKENIZED_CREDIT_CARD,
  PAYMENT_METHOD_CREDIT_CARD,
  PAYMENT_TYPE_PAY_IN_STORE,
  PAYMENT_METHOD_INVOICE_REQUEST,
  PAYMENT_METHOD_ONLINE_PAYMENT_GROUP
} from '@oracle-cx-commerce/commerce-utils/constants';
import { PAYMENT_TYPE_CASH } from '@oracle-cx-commerce/commerce-utils/constants/payments';
import { PixPaymentDetails } from './PixPaymentDetails';

/**
 * Following component renders different payment methods based on payment method type.
 *
 * @param props - Payment method type
 */
export const PaymentDetails = props => {
  const {payment = {}, textPayInStore, textPayOnline} = props;
  const {paymentMethod} = payment;

  const textPayPix = 'Pagar com Pix';

  // console.log('OpenpixPaymentDetails: ', {
  //   props,
  // });

  const getPaymentMethod = () => {
    if (paymentMethod === PAYMENT_METHOD_CREDIT_CARD || paymentMethod === PAYMENT_METHOD_TOKENIZED_CREDIT_CARD) {
      return <CreditCardPaymentDetails {...props} />;
    }
    if (paymentMethod === PAYMENT_TYPE_GIFTCARD) {
      return <GiftCardPaymentDetails {...props} />;
    }
    if (paymentMethod === PAYMENT_METHOD_INVOICE_REQUEST) {
      return <InvoicePaymentDetails {...props} />;
    }
    if (paymentMethod === PAYMENT_TYPE_PAY_IN_STORE) {
      return <GeneralPaymentDetails>{textPayInStore}</GeneralPaymentDetails>;
    }
    //Merchant can customize this to display details of online payment group such as displaying logo
    if (paymentMethod === PAYMENT_METHOD_ONLINE_PAYMENT_GROUP) {
      return <GeneralPaymentDetails>{textPayOnline}</GeneralPaymentDetails>;
    }

    // cash method OpenPix
    if (paymentMethod === PAYMENT_TYPE_CASH) {
      return <PixPaymentDetails>{textPayPix}</PixPaymentDetails>;
    }
  };

  return <>{getPaymentMethod()}</>;
};
