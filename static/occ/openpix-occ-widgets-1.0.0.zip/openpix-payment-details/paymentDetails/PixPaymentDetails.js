import React from 'react';
import Styled from '@oracle-cx-commerce/react-components/styled';
import css from './PixPaymentDetails.css';
import { QrCodeIcon } from './QrCodeIcon';
import { PaymentBillingAddressDetails } from '@oracle-cx-commerce/react-widgets/profile/payment-information/components/billing-address';

export const PixPaymentDetails = props => {
  const {className = '', children = ''} = props;
  const paymentDetails = props.payment || {};
  const {displayBillToName = false, textBillingAddress} = props;
  const {billingAddress} = paymentDetails;

  return (
    <Styled id="PixPaymentDetails" css={css}>
      <div className={`PixPaymentDetails ${className}`}>
        <QrCodeIcon />
        <div className="PixPaymentDetails__Details">{children}</div>
      </div>
      <PaymentBillingAddressDetails
        billingAddress={billingAddress}
        displayBillToName={displayBillToName}
        textBillingAddress={textBillingAddress}
      />
    </Styled>
  );
};
