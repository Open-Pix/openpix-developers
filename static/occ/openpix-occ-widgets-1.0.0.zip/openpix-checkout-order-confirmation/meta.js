import {mergeDefaultConfig} from '@oracle-cx-commerce/react-widgets/config';
import config from './config';
import * as en from './locales/en';
import * as pt_BR from './locales/pt_BR';

/**
 * Metadata for the widget.
 */
export default {
  name: '_OpenpixCheckoutOrderConfirmation',
  description: 'Description of widget OpenpixCheckoutOrderConfirmation',
  author: 'OpenPix',
  fetchers: [],
  actions: [],
  /**
   * Include references to all of our resource strings in all supported locales.
   * This will enable the component to access any resource string via its props,
   * using the locale that is currently in effect.
   */
  resources: {
    en,
    pt_BR
  },
  /**
   *  Specify configuration properties for use in Design Studio.
   */
  config: mergeDefaultConfig(config)
};
