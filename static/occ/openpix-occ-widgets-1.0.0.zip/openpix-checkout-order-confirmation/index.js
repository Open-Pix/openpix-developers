import React, {useContext, useRef} from 'react';
import Styled from '@oracle-cx-commerce/react-components/styled';
import {OrderContext, ContainerContext} from '@oracle-cx-commerce/react-ui/contexts';

import css from './styles.css';

const OpenpixCheckoutOrderConfirmation = props => {
  // locale
  const {} = props;

  const order = useContext(OrderContext);
  const containerContext = useContext(ContainerContext) || {};
  const {orderId = '', orderState, approvalSystemMessages, paymentData} = containerContext;
  const emvRef = useRef();

  // console.log('OpenpixOrderConfirmation: ', {
  //   props,
  //   order,
  //   containerContext,
  // });

  const getOpenPixProperties = () => {
    // checkout-order-confirmation
    if (paymentData) {
      const paymentGroupId = Object.keys(paymentData)[0];

      if (!paymentGroupId) {
        return null;
      }

      const paymentGroup = paymentData[paymentGroupId];

      return paymentGroup.customPaymentProperties;
    }

    if (!order) {
      return null;
    }

    // order-details
    if (order.paymentGroups.length === 0) {
      return null;
    }

    const paymentGroupId = Object.keys(order.paymentGroups)[0];

    if (!paymentGroupId) {
      return null;
    }

    const paymentGroup = order.paymentGroups[paymentGroupId];

    return paymentGroup.customPaymentProperties;
  }

  const charge = getOpenPixProperties();

  if (!charge || !charge.brCode) {
    return null;
  }

  const copyToClipboard = () => {
    emvRef.current.select();
    document.execCommand('copy');
  };

  return (
    <Styled id="OpenpixCheckoutOrderConfirmation" css={css}>
      <div className="OpenpixCheckoutOrderConfirmation__Border">
        <div className="OpenpixCheckoutOrderConfirmation__Content">
          <p className="OpenpixCheckoutOrderConfirmation__text-align-center">
            Efetue o pagamento Pix usando o <string>QRCode</string> ou usando <strong>Pix copia e cola</strong>, se
            preferir:
          </p>

          <div className="OpenpixCheckoutOrderConfirmation__container">
            <div className="OpenpixCheckoutOrderConfirmation__qrcode-container">
              <img
                className="OpenpixCheckoutOrderConfirmation__qrcode-image"
                title="QRCode Pix deste pedido."
                src={charge.qrCodeImage}
              />
            </div>
            <div className="OpenpixCheckoutOrderConfirmation__instructions">
              <ul>
                <li>
                  <span>
                    Abra o app do seu banco ou instituição financeira e <strong>entre no ambiente Pix</strong>.
                  </span>
                </li>
                <li>
                  <span>
                    Escolha a opção <strong>Pagar com QR Code</strong> e escaneie o código ao lado.
                  </span>
                </li>
                <li>
                  <span>Confirme as informações e finalize o pagamento.</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="OpenpixCheckoutOrderConfirmation__copy-paste-container">
            <p className="OpenpixCheckoutOrderConfirmation__text-align-center">
              Pagar com Pix copia e cola
              <button className="OpenpixCheckoutOrderConfirmation__copy-button" onClick={copyToClipboard}>
                Copiar
              </button>
            </p>
            <div className="OpenpixCheckoutOrderConfirmation__textarea-container">
              <textarea ref={emvRef} readOnly="" rows="5" className="OpenpixCheckoutOrderConfirmation__copy-textarea">
                {charge.brCode}
              </textarea>
            </div>
          </div>
          <p className="OpenpixCheckoutOrderConfirmation__text-align-center">
            Após o pagamento, podemos levar alguns segundos para confirmar o seu pagamento.
            <br />
            Você será avisado assim que isso ocorrer!
          </p>
        </div>
      </div>
    </Styled>
  );
};

export default OpenpixCheckoutOrderConfirmation;
