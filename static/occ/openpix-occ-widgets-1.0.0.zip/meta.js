/*
 ** Copyright (c) 2020 Oracle and/or its affiliates.
 */

export * from '@oracle-cx-commerce/react-widgets/meta';
export {default as _OpenpixCheckoutCash} from './openpix-checkout-cash/meta';
export {default as _OpenpixCheckoutOrderConfirmation} from './openpix-checkout-order-confirmation/meta';
export {default as _OpenpixPaymentDetails} from './openpix-payment-details/meta';
