<?php

$setup = new Mage_Sales_Model_Resource_Setup("core_setup");

$setup->startSetup();

// woovi_correlationid - Woovi Charge CorrelationID
if (
    !$this->getAttribute(
        Mage_Sales_Model_Order::ENTITY,
        "woovi_correlationid",
        "attribute_id"
    )
) {
    $setup->addAttribute(
        Mage_Sales_Model_Order::ENTITY,
        "woovi_correlationid",
        [
            "type" => "varchar",
            "input" => "text",
            "backend" => "",
            "frontend" => "",
            "label" => "Woovi Charge CorrelationID",
            "class" => "",
            "global" => Mage_Catalog_Model_Resource_Eav_Attribute::SCOPE_STORE,
            "visible" => false,
            "required" => false,
            "user_defined" => false,
            "default" => "",
            "searchable" => false,
            "filterable" => false,
            "comparable" => false,
            "visible_on_front" => false,
            "unique" => false,
        ]
    );
}

// woovi_paymentlinkurl - Woovi Charge Payment Link URL
if (
    !$this->getAttribute(
        Mage_Sales_Model_Order::ENTITY,
        "woovi_paymentlinkurl",
        "attribute_id"
    )
) {
    $setup->addAttribute(
        Mage_Sales_Model_Order::ENTITY,
        "woovi_paymentlinkurl",
        [
            "type" => "varchar",
            "input" => "text",
            "backend" => "",
            "frontend" => "",
            "label" => "Woovi Charge Payment Link URL",
            "class" => "",
            "global" => Mage_Catalog_Model_Resource_Eav_Attribute::SCOPE_STORE,
            "visible" => false,
            "required" => false,
            "user_defined" => false,
            "default" => "",
            "searchable" => false,
            "filterable" => false,
            "comparable" => false,
            "visible_on_front" => false,
            "unique" => false,
        ]
    );
}

// woovi_qrcodeimage - Woovi Charge Qr Code Image
if (
    !$this->getAttribute(
        Mage_Sales_Model_Order::ENTITY,
        "woovi_qrcodeimage",
        "attribute_id"
    )
) {
    $setup->addAttribute(
        Mage_Sales_Model_Order::ENTITY,
        "woovi_qrcodeimage",
        [
            "type" => "varchar",
            "input" => "text",
            "backend" => "",
            "frontend" => "",
            "label" => "Woovi Charge Qr Code Image",
            "class" => "",
            "global" => Mage_Catalog_Model_Resource_Eav_Attribute::SCOPE_STORE,
            "visible" => false,
            "required" => false,
            "user_defined" => false,
            "default" => "",
            "searchable" => false,
            "filterable" => false,
            "comparable" => false,
            "visible_on_front" => false,
            "unique" => false,
        ]
    );
}

// woovi_brcode - Woovi Charge Br Code
if (
    !$this->getAttribute(
        Mage_Sales_Model_Order::ENTITY,
        "woovi_brcode",
        "attribute_id"
    )
) {
    $setup->addAttribute(Mage_Sales_Model_Order::ENTITY, "woovi_brcode", [
        "type" => "varchar",
        "input" => "text",
        "backend" => "",
        "frontend" => "",
        "label" => "Woovi Charge Br Code",
        "class" => "",
        "global" => Mage_Catalog_Model_Resource_Eav_Attribute::SCOPE_STORE,
        "visible" => false,
        "required" => false,
        "user_defined" => false,
        "default" => "",
        "searchable" => false,
        "filterable" => false,
        "comparable" => false,
        "visible_on_front" => false,
        "unique" => false,
    ]);
}

// woovi_endtoendid - Woovi Charge Payment Link URL
if (
    !$this->getAttribute(
        Mage_Sales_Model_Order::ENTITY,
        "woovi_endtoendid",
        "attribute_id"
    )
) {
    $setup->addAttribute(Mage_Sales_Model_Order::ENTITY, "woovi_endtoendid", [
        "type" => "varchar",
        "input" => "text",
        "backend" => "",
        "frontend" => "",
        "label" => "Woovi Charge EndToEndId",
        "class" => "",
        "global" => Mage_Catalog_Model_Resource_Eav_Attribute::SCOPE_STORE,
        "visible" => false,
        "required" => false,
        "user_defined" => false,
        "default" => "",
        "searchable" => false,
        "filterable" => false,
        "comparable" => false,
        "visible_on_front" => false,
        "unique" => false,
    ]);
}

$setup->endSetup();
