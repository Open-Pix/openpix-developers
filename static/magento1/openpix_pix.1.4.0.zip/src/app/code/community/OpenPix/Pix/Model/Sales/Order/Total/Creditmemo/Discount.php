<?php

class OpenPix_Pix_Model_Sales_Order_Total_Creditmemo_Discount extends
    Mage_Sales_Model_Order_Creditmemo_Total_Abstract
{
    /**
     * Collect creditmemo total
     *
     * @param Mage_Sales_Model_Order_Creditmemo $creditmemo
     *
     * @return OpenPix_Pix_Model_Sales_Order_Total_Creditmemo_Discount
     */
    public function collect(Mage_Sales_Model_Order_Creditmemo $creditmemo)
    {
        $creditmemo->setGiftbackDiscount(0);
        $creditmemo->setBaseGiftbackDiscount(0);
        $order = $creditmemo->getOrder();

        $giftbackDiscount = $order->getGiftbackDiscount();
        $baseGiftbackDiscount = $order->getGiftbackDiscount();

        $totalOpenpixDiscount = $giftbackDiscount > 0 ? $giftbackDiscount : 0;
        $baseTotalOpenpixDiscount =
            $baseGiftbackDiscount > 0 ? $baseGiftbackDiscount : 0;

        $creditmemo->setGiftbackDiscount(-$totalOpenpixDiscount);
        $creditmemo->setBaseGiftbackDiscount(-$baseTotalOpenpixDiscount);

        $creditmemo->setGrandTotal(
            $creditmemo->getGrandTotal() - $totalOpenpixDiscount
        );

        $creditmemo->setBaseGrandTotal(
            $creditmemo->getBaseGrandTotal() - $baseTotalOpenpixDiscount
        );

        return $this;
    }
}
