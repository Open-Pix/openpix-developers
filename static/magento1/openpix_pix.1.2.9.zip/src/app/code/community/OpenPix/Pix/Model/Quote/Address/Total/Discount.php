<?php

class OpenPix_Pix_Model_Quote_Address_Total_Discount extends
    Mage_Sales_Model_Quote_Address_Total_Abstract
{
    use OpenPix_Pix_Trait_ExceptionMessenger;
    use OpenPix_Pix_Trait_LogMessenger;

    /**
     * Initialize discount collector
     */
    public function __construct()
    {
        $this->setCode("giftback_discount");
    }

    /**
     * @inheritDoc
     */
    public function collect(Mage_Sales_Model_Quote_Address $address)
    {
        parent::collect($address);

        $helper = Mage::helper("openpix_pix");
        if (!$helper->getConfig("active")) {
            return $this;
        }

        $items = $address->getAllItems();
        if (!count($items)) {
            return $this;
        }

        $quote = $address->getQuote();
        $paymentMethod = $quote->getPayment()->getMethod();
        if (!$this->validatePaymentMethod($paymentMethod)) {
            $this->updateTotal($address, 0);
            return $this;
        }

        $discountAmount = $this->getDiscountFromCustomer(
            $quote,
            $address->getDiscountAmount()
        );

        if ($discountAmount <= 0) {
            $this->updateTotal($address, 0);
            return $this;
        }

        $this->updateTotal($address, $discountAmount);

        $address->setGrandTotal(
            $address->getGrandTotal() - $address->getGiftbackDiscount()
        );
        $address->setBaseGrandTotal(
            $address->getBaseGrandTotal() - $address->getBaseGiftbackDiscount()
        );

        return $this;
    }

    /**
     * @inheritDoc
     */
    public function fetch(Mage_Sales_Model_Quote_Address $address)
    {
        $amount = $address->getGiftbackDiscount();

        if ($amount != 0) {
            $title = Mage::helper("sales")->__("Desconto Giftback");
            $address->addTotal([
                "code" => "giftback_discount",
                "title" => $title,
                "value" => -$amount,
            ]);
        }
        return $this;
    }

    /**
     * Update giftback discount to address and quote
     *
     * @param $address
     * @param $amount
     *
     * @return void
     */
    protected function updateTotal($address, $amount)
    {
        $address
            ->setGiftbackDiscount($amount)
            ->setBaseGiftbackDiscount($amount);
        $address
            ->getQuote()
            ->setGiftbackDiscount($amount)
            ->setBaseGiftbackDiscount($amount);
    }

    /**
     * Validate payment method is openpix or not
     *
     * @param string $paymentMethod
     *
     * @return bool
     */
    protected function validatePaymentMethod($paymentMethod)
    {
        if (empty($paymentMethod)) {
            return false;
        }

        return strcasecmp(
            $paymentMethod,
            Mage::getModel("openpix_pix/paymentMethod")->getMethodName()
        ) == 0;
    }

    protected function getDiscountFromCustomer($quote, $totalDiscountAmount)
    {
        $customerSession = Mage::getSingleton("customer/session");
        if (!$customerSession->isLoggedIn()) {
            return 0;
        }

        $customerTaxVat = $quote->getCustomerTaxvat();
        if (!$customerTaxVat) {
            return 0;
        }

        try {
            $customerGiftBackBalance = $this->getCustomerBalanceByTaxId(
                $customerTaxVat
            );
        } catch (\Exception $exception) {
            $customerGiftBackBalance = 0;
        }

        if ($customerGiftBackBalance <= 0) {
            return 0;
        }

        return $this->calculateAndConvertBalance(
            $customerGiftBackBalance,
            $quote,
            $totalDiscountAmount
        );
    }

    protected function getCustomerBalanceByTaxId($customerTaxVat)
    {
        $this->log("getCustomerBalanceByTaxId");
        if (empty($customerTaxVat)) {
            return 0;
        }

        $helper = Mage::helper("openpix_pix");
        $appID = $helper->getAppID();
        $apiUrl = Mage::helper("openpix_pix/config")->getOpenPixApiUrl();

        $headers = [
            "Accept: application/json",
            "Content-Type: application/json; charset=utf-8",
            "Authorization: " . $appID,
            "platform: MAGENTO1",
            "version: 1.2.4",
        ];

        $curl = curl_init();
        curl_setopt(
            $curl,
            CURLOPT_URL,
            $apiUrl . "/api/v1/giftback/balance/" . $customerTaxVat
        );
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

        $response = curl_exec($curl);
        $statusCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);

        if (curl_errno($curl) || $response === false) {
            curl_close($curl);
            return 0;
        }

        curl_close($curl);
        if ($statusCode !== 200) {
            return 0;
        }

        $result = json_decode($response, true);

        $this->log("customer giftback balance " . $result["balance"]);

        if (isset($result["balance"]) && $result["balance"] > 0) {
            return $result["balance"];
        }

        return 0;
    }

    protected function calculateAndConvertBalance(
        $balance,
        $quote,
        $totalDiscountAmount
    ) {
        if ($balance == 0 || empty($quote)) {
            return 0;
        }

        $address = $quote->getShippingAddress();
        $totalAmount =
            $address->getBaseSubtotal() +
            $address->getShippingAmount() +
            $totalDiscountAmount;

        $formattedBalance = round(abs($balance / 100), 2);

        $this->log("calculateAndConvertBalance totalAmount " . $totalAmount);
        $this->log(
            "calculateAndConvertBalance formattedBalance " . $formattedBalance
        );

        if ($formattedBalance > $totalAmount) {
            return round($totalAmount - 0.01, 2);
        }

        return $formattedBalance;
    }
}
