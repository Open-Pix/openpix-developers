<?php

class OpenPix_Pix_VersionController extends Mage_Core_Controller_Front_Action
{
    public function indexAction()
    {
        // improve this to do programmatically
        echo "OpenPix Magento 1 Version: 1.5.0";
    }
}
