<?php

class Woovi_Pix_WebhookController extends Mage_Core_Controller_Front_Action
{
    use Woovi_Pix_Trait_LogMessenger;
    use Woovi_Pix_Trait_ExceptionMessenger;

    /**
     * Webhook Route
     */
    public function indexAction()
    {
        $this->logWebhook(sprintf("Start webhook"), Zend_Log::INFO);

        $handler = Mage::helper("woovi_pix/webhookHandler");

        if (!$this->validateRequest()) {
            $this->logWebhook(sprintf("Invalid Request"), Zend_Log::ERR);

            $authorization = $this->getRequest()->getHeader("Authorization");

            $this->logWebhook(
                sprintf("Invalid Authorization: " . $authorization),
                Zend_Log::ERR
            );

            $ip = Mage::helper("core/http")->getRemoteAddr();

            $this->logWebhook(
                sprintf("Invalid webhook attempt from IP %s", $ip),
                Zend_Log::WARN
            );

            header("HTTP/1.2 400 Bad Request");
            $response = [
                "error" => "Invalid Request",
                "description" =>
                    "Invalid authorization header",
                "sentAuthorizations" => [
                    "X-Woovi-Authorization" => $this->getRequest()->getHeader(
                        "X-Woovi-Authorization"
                    ),
                    "Authorization" => $this->getRequest()->getHeader(
                        "authorization"
                    ),
                    "authorization" => $this->getRequest()->getQuery(
                        "authorization"
                    ),
                ],
                "field" => "authorization header",
            ];
            echo json_encode($response);
            exit();
        }

        $body = file_get_contents("php://input");

        $result = $handler->handle($body);

        $this->logWebhook(
            sprintf("Webhook result " . json_encode($result)),
            Zend_Log::INFO
        );

        if (isset($result["error"])) {
            header("HTTP/1.2 400 Bad Request");
            $response = [
                "error" => "Invalid Webhook Authorization: " . $result["error"],
            ];
            echo json_encode($response);
            exit();
        }

        header("HTTP/1.1 200 OK");

        $response = [
            "success" => $result["success"],
        ];
        echo json_encode($response);
        exit();
    }

    /**
     * Validate webhook authorization
     *
     * @return bool
     */
    protected function validateRequest()
    {
        $webhookAuthSystem = Mage::helper(
            "woovi_pix"
        )->getWebhookAuthorization();

        $webhookAuthHeader = $this->getRequest()->getHeader("Authorization");
        $webhookAuthWooviHeader = $this->getRequest()->getHeader(
            "X-Woovi-Authorization"
        );
        $webhookAuthQueryString = $this->getRequest()->getQuery(
            "authorization"
        );

        $this->logWebhook(
            sprintf(
                "Webhook Authorization Header: %s",
                $webhookAuthHeader
            ),
            Zend_Log::INFO
        );

        $this->logWebhook(
            sprintf(
                "Webhook Authorization Woovi Header: %s",
                $webhookAuthWooviHeader
            ),
            Zend_Log::INFO
        );

        $this->logWebhook(
            sprintf(
                "Webhook Authorization Arg: %s",
                $webhookAuthQueryString         
            ),
            Zend_Log::INFO
        );

        $isAuthHeaderValid = $webhookAuthSystem === $webhookAuthHeader;

        $isAuthWooviHeaderValid =
            $webhookAuthSystem === $webhookAuthWooviHeader;
        $isAuthQueryStringValid =
            $webhookAuthSystem === $webhookAuthQueryString;

        return $isAuthHeaderValid ||
            $isAuthWooviHeaderValid ||
            $isAuthQueryStringValid;
    }
}
