<?php

class Woovi_Pix_Model_Observer
{
    use Woovi_Pix_Trait_ExceptionMessenger;
    use Woovi_Pix_Trait_LogMessenger;

    public function validateCustomer($customer)
    {
        $taxID = $customer["taxID"];

        $hasTaxID = isset($taxID);
        $isValidTaxIDLength = strlen($taxID) === 11;
        $isTaxIDValid = $hasTaxID && $isValidTaxIDLength;

        return $isTaxIDValid;
    }

    public function applyGiftback(Varien_Event_Observer $observer)
    {
        $this->log("Woovi Observer Start", "woovi_event.log");

        $order = $observer->getEvent()->getOrder();
        $quote = Mage::getSingleton("checkout/session")->getQuote();

        $customer = $this->orderHelper()->getCustomerData($quote, $order);

        if (!$this->validateCustomer($customer)) {
            return null;
        }

        $this->log(
            "Woovi Observer after validate customer",
            "woovi_event.log"
        );

        $app_ID = $this->helper()->getAppID();
        $this->log("Woovi Observer app_ID" . $app_ID, "woovi_event.log");

        if (!$app_ID) {
            $this->log(
                "Woovi Observer - AppID not found",
                "woovi_event.log"
            );
            $this->error(
                "An error occurred while creating your order - appID not found"
            );
            return null;
        }

        $this->log("Woovi Observer app_ID after if", "woovi_event.log");

        $apiUrl = Mage::helper("woovi_pix/config")->getWooviApiUrl();
        $this->log("Woovi Observer apiUrl " . $apiUrl, "woovi_event.log");

        $headers = [
            "Accept: application/json",
            "Content-Type: application/json; charset=utf-8",
            "Authorization: " . $app_ID,
            "platform: MAGENTO1",
            "version: 1.2.4",
        ];

        $this->log(
            "woovi observer headers " . json_encode($headers, true),
            "woovi_event.log"
        );

        $curl = curl_init();
        curl_setopt(
            $curl,
            CURLOPT_URL,
            $apiUrl . "/api/v1/giftback/balance/" . $customer["taxID"]
        );
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

        $response = curl_exec($curl);
        $statusCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);

        if (curl_errno($curl) || $response === false) {
            $this->debugJson(
                "Woovi Observer Curl Error - while creating Pix ",
                json_encode($response)
            );
            $this->error("An error occurred while creating your order");
            curl_close($curl);

            return false;
        }

        curl_close($curl);

        if ($statusCode === 401) {
            $this->log(
                "Woovi Observer Error 401 - Invalid AppID",
                "woovi_event.log"
            );
            $this->error("An error occurred while creating your order");

            return false;
        }

        if ($statusCode === 400) {
            $this->debugJson(
                "Woovi Observer Error 400 - ",
                json_encode($response),
                "woovi_event.log"
            );
            $this->error("An error occurred while creating your order");

            return false;
        }

        if ($statusCode !== 200) {
            $this->debugJson(
                "Woovi Observer Error 400 - while creating Pix ",
                json_encode($response),
                "woovi_event.log"
            );
            $this->error("An error occurred while creating your order");
            curl_close($curl);

            return false;
        }

        $response = json_decode($response, true);

        $this->log(
            "Woovi Observer customer giftback balance response " .
                json_encode($response),
            "woovi_event.log"
        );

        $giftbackBalance = $response["balance"];
        $this->log(
            "Woovi Observer giftbackBalance " . $giftbackBalance,
            "woovi_event.log"
        );

        $giftbackBalanceRounded = round(
            $this->helper()->absint($giftbackBalance) / 100,
            3
        );
        $this->log(
            "Woovi Observer giftbackBalance " . $giftbackBalance,
            "woovi_event.log"
        );

        $this->log(
            "Woovi - getBaseGrandTotal " . $order->getBaseGrandTotal(),
            "woovi_event.log"
        );
        $this->log(
            "Woovi - getGrandTotal" . $order->getGrandTotal(),
            "woovi_event.log"
        );

        // @todo calculate giftback balance on order total
        // @todo set the discount on order
        // @todo send the discount as giftbackAppliedValue to charge post api
    }

    protected function helper()
    {
        return Mage::helper("woovi_pix");
    }

    protected function orderHelper()
    {
        return Mage::helper("woovi_pix/order");
    }
}
