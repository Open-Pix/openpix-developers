<?php

class OpenPix_Pix_WebhookController extends Mage_Core_Controller_Front_Action
{
    use OpenPix_Pix_Trait_LogMessenger;
    use OpenPix_Pix_Trait_ExceptionMessenger;

    /**
     * Webhook Route
     */
    public function indexAction()
    {
        $this->logWebhook(sprintf("Start webhook"), Zend_Log::INFO);

        $handler = Mage::helper("openpix_pix/webhookHandler");

        $body = file_get_contents("php://input");

        if (!$this->validateRequest($body)) {
            $this->logWebhook(sprintf("Invalid Request"), Zend_Log::ERR);

            $this->logWebhook(
                sprintf("Invalid webhook signature: "),
                Zend_Log::ERR
            );

            $ip = Mage::helper("core/http")->getRemoteAddr();

            $this->logWebhook(
                sprintf("Invalid webhook attempt from IP %s", $ip),
                Zend_Log::WARN
            );

            header("HTTP/1.2 400 Bad Request");
            $response = [
                "error" => "Invalid Webhook Signature",
                "description" =>
                    "Invalid Webhook Signature",
                "field" => "authorization header",
            ];
            echo json_encode($response);
            exit();
        }


        $result = $handler->handle($body);

        $this->logWebhook(
            sprintf("Webhook result " . json_encode($result)),
            Zend_Log::INFO
        );

        if (isset($result["error"])) {
            header("HTTP/1.2 400 Bad Request");
            $response = [
                "error" => $result["error"],
            ];
            echo json_encode($response);
            exit();
        }

        header("HTTP/1.1 200 OK");

        $response = [
            "success" => $result["success"],
        ];
        echo json_encode($response);
        exit();
    }

    public function verifySignature($payload, $signature)
    {
        $publicKey = Mage::helper("openpix_pix/config")->getOpenPixKey();

        $verify = openssl_verify(
            $payload,
            base64_decode($signature),
            base64_decode($publicKey),
            'sha256WithRSAEncryption'
        );

        $log = [
            "signature" => $signature,
            "payload" => $payload,
            "isValid" => $verify,
            "publicKey" => $publicKey,
        ];
        $this->logWebhook(
            sprintf(
                "\nSignature: %s\nPayload: %s\nisValid: %s\npublicKey: %s",
                $signature, $payload, $verify == 1 ? "true" : "false", $publicKey
            ),
            Zend_Log::INFO
        );
        return $verify;
    }

    /**
     * Validate webhook authorization
     *
     * @return bool
     */
    protected function validateRequest($payload)
    {

        $signatureHeader = $this->getRequest()->getHeader("x-webhook-signature");

        $isValid = $this->verifySignature($payload, $signatureHeader);


        return $isValid;
    }
}
