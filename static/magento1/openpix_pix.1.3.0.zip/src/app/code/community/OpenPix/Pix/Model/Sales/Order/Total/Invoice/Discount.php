<?php

class OpenPix_Pix_Model_Sales_Order_Total_Invoice_Discount extends
    Mage_Sales_Model_Order_Invoice_Total_Abstract
{
    /**
     * Collect invoice total
     *
     * @param Mage_Sales_Model_Order_Invoice $invoice
     *
     * @return OpenPix_Pix_Model_Sales_Order_Total_Invoice_Discount
     */
    public function collect(Mage_Sales_Model_Order_Invoice $invoice)
    {
        $invoice->setGiftbackDiscount(0);
        $invoice->setBaseGiftbackDiscount(0);
        $order = $invoice->getOrder();

        $giftbackDiscount = $order->getGiftbackDiscount();
        $baseGiftbackDiscount = $order->getGiftbackDiscount();

        $totalOpenpixDiscount = $giftbackDiscount > 0 ? $giftbackDiscount : 0;
        $baseTotalOpenpixDiscount =
            $baseGiftbackDiscount > 0 ? $baseGiftbackDiscount : 0;

        $invoice->setGiftbackDiscount(-$totalOpenpixDiscount);
        $invoice->setBaseGiftbackDiscount(-$baseTotalOpenpixDiscount);

        $invoice->setGrandTotal(
            $invoice->getGrandTotal() - $totalOpenpixDiscount
        );

        $invoice->setBaseGrandTotal(
            $invoice->getBaseGrandTotal() - $baseTotalOpenpixDiscount
        );

        return $this;
    }
}
