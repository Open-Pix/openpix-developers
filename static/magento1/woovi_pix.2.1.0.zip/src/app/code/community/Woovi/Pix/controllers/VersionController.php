<?php

class Woovi_Pix_VersionController extends Mage_Core_Controller_Front_Action
{
    public function indexAction()
    {
        // improve this to do programmatically
        echo "Woovi Magento 1 Version: 2.1.0";
    }
}
