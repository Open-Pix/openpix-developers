<?php

class Woovi_Pix_Adminhtml_AjaxController extends Mage_Adminhtml_Controller_Action
{
    public function prepareWooviOneclickAction()
    {
        // Remove current App ID

        Mage::app()->cleanCache();
        Mage::getModel("core/config")->saveConfig(
            "payment/woovi_pix/app_ID",
            ""
        );

        // Determine redirect URL

        $webhookUrl = Mage::getUrl("woovi/webhook");
        $platformUrl = Mage::helper("woovi_pix/config")->getWooviPlatformUrl();
        $newPlatformIntegrationUrl = $platformUrl . "/home/applications/magento1/add/oneclick?website=" . $webhookUrl;

        $result = json_encode([
            "webhook_url" => $webhookUrl,
            "redirect_url" => $newPlatformIntegrationUrl,
        ]);

        $response = Mage::app()->getResponse();

        $response->setHeader("Content-type", "application/json");
        $response->setBody($result);
    }
}