<?php

class OpenPix_Pix_Helper_Config extends Mage_Core_Helper_Abstract
{
    public function getOpenPixApiUrl()
    {
        // production
        return "https://api.openpix.com.br";
    }

    public function getOpenPixPluginUrlScript()
    {
        return "https://plugin.openpix.com.br/v1/openpix.js";
    }
}
