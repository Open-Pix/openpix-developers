/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
/*global define*/
define(['Woovi_Pix/js/view/summary/woovi_discount'], function (Component) {
  'use strict';
  return Component.extend({
    defaults: {
      template: 'Woovi_Pix/cart/totals/woovi_discount',
    },
    /**
     * @override
     *
     * @returns {boolean}
     */
    isDisplayed: function () {
      return this.getPureValue() !== 0;
    },
  });
});
