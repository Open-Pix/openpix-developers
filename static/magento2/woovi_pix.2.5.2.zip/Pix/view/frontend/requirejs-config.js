let config = {
  map: {
    '*': {
      Woovi: 'https://plugin.woovi.com/v1/woovi.js',
    },
  },
};
