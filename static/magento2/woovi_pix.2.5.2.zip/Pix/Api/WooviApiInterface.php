<?php

namespace Woovi\Pix\Api;

interface WooviApiInterface
{
    /**
     * GET version of Woovi magento2 webapi
     * @return string
     */
    public function getVersion();
}
