<?php

namespace Woovi\Pix\Helper;
class WooviConfig
{
    const WOOVI_ENV = 'production';

    public function __construct()
    {
    }

    public function getWooviApiUrl()
    {
        return 'https://api.woovi.com';
    }

    public function getWooviPluginUrlScript(): string
    {
        return 'https://plugin.woovi.com/v1/woovi.js';
    }
}
